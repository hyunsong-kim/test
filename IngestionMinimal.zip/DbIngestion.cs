using System;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// A/B: 자동 플러시(건수/시간), C: 수동 플러시 전용
/// </summary>
public sealed class DbIngestion : IDisposable
{
    private readonly SimpleBuffer<RowA> _a;
    private readonly SimpleBuffer<RowB> _b;
    private readonly SimpleBuffer<RowC> _c;

    public DbIngestion(string connStr,
        int countThreshold = 5000,
        int timeThresholdMs = 500)
    {
        var time = TimeSpan.FromMilliseconds(timeThresholdMs);

        _a = new SimpleBuffer<RowA>(rows => OracleWriters.InsertAAsync(connStr, rows),
                                    countThreshold, time, autoFlush: true);

        _b = new SimpleBuffer<RowB>(rows => OracleWriters.InsertBAsync(connStr, rows),
                                    countThreshold, time, autoFlush: true);

        // C는 수동 플러시만
        _c = new SimpleBuffer<RowC>(rows => OracleWriters.InsertCAsync(connStr, rows),
                                    int.MaxValue, TimeSpan.FromDays(3650), autoFlush: false);
    }

    public void AddA(RowA row) => _a.Add(row);
    public void AddB(RowB row) => _b.Add(row);
    public void AddC(RowC row) => _c.Add(row);

    public Task FlushCNowAsync() => _c.FlushNowAsync();

    public async Task StopAsync()
    {
        await _a.StopAsync().ConfigureAwait(false);
        await _b.StopAsync().ConfigureAwait(false);
        await _c.StopAsync().ConfigureAwait(false);
    }

    public void Dispose()
    {
        _a.Dispose();
        _b.Dispose();
        _c.Dispose();
    }
}

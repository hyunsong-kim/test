# IngestionMinimal (net48 & net6 겸용)

- **의존성 최소화**: `System.Runtime.Remoting` 사용 안 함, `System.Threading.Channels`도 불필요
- **.NET Framework 4.8**과 **.NET 6** 모두 바로 포함해 사용할 수 있는 **순수 C# 파일 5개**
- A/B: 건수/시간 자동 플러시, C: 수동 플러시
- Oracle Array Binding 사용 (NuGet: `Oracle.ManagedDataAccess`)

## 사용 방법
1) 본 폴더의 5개 `.cs` 파일을 **그냥 당신의 프로젝트**에 추가합니다.
2) 프로젝트에 NuGet 패키지 **Oracle.ManagedDataAccess**를 추가합니다.
3) 아래 예시처럼 사용하세요.

```csharp
var connStr = "User Id=user;Password=pass;Data Source=HOST:1521/SVC;";
var ing = new DbIngestion(connStr);

// 데이터 투입
ing.AddA(new RowA { Id = 1, Ts = DateTime.UtcNow, Val = 1.23m });
ing.AddB(new RowB { Id = 2, Code = "X", Qty = 10 });
ing.AddC(new RowC { EventId = Guid.NewGuid(), Ts = DateTime.UtcNow, Payload = "hello" });

// C는 원하는 시점에만
await ing.FlushCNowAsync();

// 종료 시
await ing.StopAsync();   // 가능하면 권장
ing.Dispose();           // 동기 종료가 필요하면
```

## 기본 파라미터
- 배치 사이즈: 5,000 (A, B)
- 시간 플러시: 500ms (A, B)
- C는 수동 플러시만 동작

> 타임아웃/배치 사이즈는 `DbIngestion` 생성자에서 조정 가능합니다.

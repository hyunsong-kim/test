// 참고용 예제 (원하면 프로젝트에 포함하지 않아도 됨)
using System;
using System.Globalization;
using System.Threading.Tasks;

public static class Example
{
    public static async Task RunAsync()
    {
        var connStr = Environment.GetEnvironmentVariable("ORACLE_CONNSTR")
                      ?? "User Id=user;Password=pass;Data Source=HOST:1521/SERVICE;";

        var ing = new DbIngestion(connStr);

        for (int i = 0; i < 12345; i++)
        {
            ing.AddA(new RowA { Id = i, Ts = DateTime.UtcNow, Val = (decimal)(i * 0.1) });
            ing.AddB(new RowB { Id = i, Code = "CD" + (i % 10), Qty = i % 100 });
            ing.AddC(new RowC { EventId = Guid.NewGuid(), Ts = DateTime.UtcNow, Payload = "payload-" + i });
        }

        // 특정 시점에만 C 플러시
        await ing.FlushCNowAsync();

        await ing.StopAsync();
    }
}

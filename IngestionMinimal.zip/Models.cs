using System;

public sealed class RowA
{
    public long Id { get; set; }
    public DateTime Ts { get; set; }
    public decimal Val { get; set; }
}

public sealed class RowB
{
    public long Id { get; set; }
    public string Code { get; set; }
    public int Qty { get; set; }
}

public sealed class RowC
{
    public Guid EventId { get; set; }
    public DateTime Ts { get; set; }
    public string Payload { get; set; }
}

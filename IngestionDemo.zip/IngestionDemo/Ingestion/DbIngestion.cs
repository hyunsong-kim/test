using System;
using System.Threading.Tasks;

namespace IngestionDemo.Ingestion
{
    public sealed class DbIngestion : IAsyncDisposable
    {
        private readonly ITableBuffer<RowA> _a;
        private readonly ITableBuffer<RowB> _b;
        private readonly ITableBuffer<RowC> _c;

        public DbIngestion(string connStr)
        {
            _a = new TableBuffer<RowA>(
                flushFunc: rows => OracleWriters.InsertAAsync(connStr, rows),
                countThreshold: 5_000,
                timeThreshold: TimeSpan.FromMilliseconds(500),
                autoFlushEnabled: true);

            _b = new TableBuffer<RowB>(
                flushFunc: rows => OracleWriters.InsertBAsync(connStr, rows),
                countThreshold: 5_000,
                timeThreshold: TimeSpan.FromMilliseconds(500),
                autoFlushEnabled: true);

            _c = new TableBuffer<RowC>(
                flushFunc: rows => OracleWriters.InsertCAsync(connStr, rows),
                countThreshold: int.MaxValue,
                timeThreshold: TimeSpan.FromDays(3650),
                autoFlushEnabled: false);
        }

        public ValueTask AddAAsync(RowA row, System.Threading.CancellationToken ct = default) => _a.AddAsync(row, ct);
        public ValueTask AddBAsync(RowB row, System.Threading.CancellationToken ct = default) => _b.AddAsync(row, ct);
        public ValueTask AddCAsync(RowC row, System.Threading.CancellationToken ct = default) => _c.AddAsync(row, ct);

        public System.Threading.Tasks.Task FlushCNowAsync(System.Threading.CancellationToken ct = default) => _c.FlushNowAsync(ct);

        public async ValueTask DisposeAsync()
        {
            await _a.DisposeAsync();
            await _b.DisposeAsync();
            await _c.DisposeAsync();
        }
    }
}

using System;

namespace IngestionDemo.Ingestion
{
    public sealed record RowA(long Id, DateTime Ts, decimal Val);
    public sealed record RowB(long Id, string Code, int Qty);
    public sealed record RowC(Guid EventId, DateTime Ts, string Payload);
}

using System;
using System.Linq;
using System.Threading.Tasks;

namespace IngestionDemo.Ingestion
{
    /// <summary>
    /// 파티션 키 기반으로 다중 버퍼에 분산하여 병렬 쓰기(옵션).
    /// </summary>
    public sealed class PartitionedBuffer<T> : IAsyncDisposable
    {
        private readonly TableBuffer<T>[] _parts;
        private readonly Func<int, System.Collections.Generic.IReadOnlyList<T>, Task> _flushFuncByPart;
        private readonly int _partitions;

        public PartitionedBuffer(int partitions,
            Func<int, System.Collections.Generic.IReadOnlyList<T>, Task> flushFuncByPart,
            int countThreshold, TimeSpan timeThreshold, bool autoFlush = true)
        {
            _partitions = partitions;
            _flushFuncByPart = flushFuncByPart;
            _parts = Enumerable.Range(0, partitions)
                .Select(p => new TableBuffer<T>(rows => _flushFuncByPart(p, rows), countThreshold, timeThreshold, autoFlush))
                .ToArray();
        }

        public System.Threading.Tasks.ValueTask AddAsync(T row, int partitionKey, System.Threading.CancellationToken ct = default)
            => _parts[partitionKey % _partitions].AddAsync(row, ct);

        public Task FlushAllAsync() => Task.WhenAll(_parts.Select(p => p.FlushNowAsync()));

        public async ValueTask DisposeAsync()
        {
            foreach (var p in _parts) await p.DisposeAsync();
        }
    }
}

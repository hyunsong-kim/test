using System;
using System.Threading.Tasks;
using System.Threading;
using IngestionDemo.Ingestion;

internal class Program
{
    static async Task Main(string[] args)
    {
        // TODO: 실제 연결문자열로 교체하세요 (예: "User Id=...;Password=...;Data Source=HOST:1521/SERVICE;")
        var connStr = Environment.GetEnvironmentVariable("ORACLE_CONNSTR") ?? "User Id=user;Password=pass;Data Source=HOST:1521/SERVICE;";

        await using var ingestion = new DbIngestion(connStr);

        // A/B: 자동 플러시 (건수/시간)
        for (int i = 0; i < 12_345; i++)
        {
            await ingestion.AddAAsync(new RowA(Id: i, Ts: DateTime.UtcNow, Val: i * 0.1m));
            await ingestion.AddBAsync(new RowB(Id: i, Code: "CD" + (i%10), Qty: i%100));
        }

        // C: 수동 플러시
        for (int i = 0; i < 2000; i++)
        {
            await ingestion.AddCAsync(new RowC(EventId: Guid.NewGuid(), Ts: DateTime.UtcNow, Payload: $"payload-{i}"));
        }

        // 특정 시점에 수동 플러시
        await ingestion.FlushCNowAsync();

        Console.WriteLine("Demo finished (buffers disposed will also flush remaining).");
    }
}

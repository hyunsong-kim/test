# IngestionDemo

C# 실시간 적재 템플릿 (Oracle Array Binding 기반).

## 구성
- `Ingestion/Models.cs` : 테이블 A,B,C 행 모델
- `Ingestion/TableBuffer.cs` : 채널 기반 버퍼 + 자동/수동 플러시
- `Ingestion/OracleWriters.cs` : Oracle Array Binding 삽입
- `Ingestion/DbIngestion.cs` : A/B 자동, C 수동 플러시 조합
- `Ingestion/PartitionedBuffer.cs` : 파티션 기반 병렬 라우팅(옵션)
- `Program.cs` : 사용 예시

## 빌드/실행
```bash
dotnet restore
dotnet run
```

> NuGet: `Oracle.ManagedDataAccess`, `System.Threading.Channels` 필요

## 배치 사이즈/타임아웃
- 기본: 5,000 건 / 500ms (코드 내에서 수정 가능)

## 주의
- 실제 컬럼/테이블명, 인덱스/파티션 키는 환경에 맞게 조정
- 대량 초기 적재 시 PK/Unique 외 인덱스 최소화, 필요 시 후빌드 권장

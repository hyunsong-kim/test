using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Data;
using Oracle.ManagedDataAccess.Client;

public static class OracleWriters
{
    public static async Task InsertAAsync(string connStr, IReadOnlyList<RowA> rows)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var cmd = conn.CreateCommand())
            {
                cmd.BindByName = true;
                cmd.CommandText = @"INSERT INTO TBL_A (ID, TS, VAL) VALUES (:ID, :TS, :VAL)";
                cmd.ArrayBindCount = rows.Count;
                cmd.Parameters.Add(":ID", OracleDbType.Int64, rows.Select(x => x.Id).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":TS", OracleDbType.TimeStamp, rows.Select(x => x.Ts).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":VAL", OracleDbType.Decimal, rows.Select(x => x.Val).ToArray(), ParameterDirection.Input);
                await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            }
        }
    }

    public static async Task InsertBAsync(string connStr, IReadOnlyList<RowB> rows)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var cmd = conn.CreateCommand())
            {
                cmd.BindByName = true;
                cmd.CommandText = @"INSERT INTO TBL_B (ID, CODE, QTY) VALUES (:ID, :CODE, :QTY)";
                cmd.ArrayBindCount = rows.Count;
                cmd.Parameters.Add(":ID", OracleDbType.Int64, rows.Select(x => x.Id).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":CODE", OracleDbType.Varchar2, rows.Select(x => x.Code).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":QTY", OracleDbType.Int32, rows.Select(x => x.Qty).ToArray(), ParameterDirection.Input);
                await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            }
        }
    }

    public static async Task InsertCAsync(string connStr, IReadOnlyList<RowC> rows)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var cmd = conn.CreateCommand())
            {
                cmd.BindByName = true;
                cmd.CommandText = @"INSERT INTO TBL_C (EVENT_ID, TS, PAYLOAD) VALUES (:EVENT_ID, :TS, :PAYLOAD)";
                cmd.ArrayBindCount = rows.Count;
                cmd.Parameters.Add(":EVENT_ID", OracleDbType.Raw, rows.Select(x => x.EventId.ToByteArray()).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":TS", OracleDbType.TimeStamp, rows.Select(x => x.Ts).ToArray(), ParameterDirection.Input);
                cmd.Parameters.Add(":PAYLOAD", OracleDbType.Clob, rows.Select(x => x.Payload).ToArray(), ParameterDirection.Input);
                await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
            }
        }
    }
}

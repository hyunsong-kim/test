using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

public static class BulkCopyWriters
{
    private static DataTable ToDataTableA(IReadOnlyList<RowA> rows)
    {
        var dt = new DataTable("TBL_A");
        dt.Columns.Add("ID", typeof(long));
        dt.Columns.Add("TS", typeof(DateTime));
        dt.Columns.Add("VAL", typeof(decimal));
        foreach (var r in rows) dt.Rows.Add(r.Id, r.Ts, r.Val);
        return dt;
    }

    private static DataTable ToDataTableB(IReadOnlyList<RowB> rows)
    {
        var dt = new DataTable("TBL_B");
        dt.Columns.Add("ID", typeof(long));
        dt.Columns.Add("CODE", typeof(string));
        dt.Columns.Add("QTY", typeof(int));
        foreach (var r in rows) dt.Rows.Add(r.Id, r.Code, r.Qty);
        return dt;
    }

    private static DataTable ToDataTableC(IReadOnlyList<RowC> rows)
    {
        var dt = new DataTable("TBL_C");
        dt.Columns.Add("EVENT_ID", typeof(byte[]));
        dt.Columns.Add("TS", typeof(DateTime));
        dt.Columns.Add("PAYLOAD", typeof(string));
        foreach (var r in rows) dt.Rows.Add(r.EventId.ToByteArray(), r.Ts, r.Payload);
        return dt;
    }

    public static async Task BulkInsertAAsync(string connStr, IReadOnlyList<RowA> rows,
        int batchSize = 5000, int timeoutSec = 0, bool useInternalTxn = True)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var bulk = new OracleBulkCopy(conn, useInternalTxn ? OracleBulkCopyOptions.UseInternalTransaction : OracleBulkCopyOptions.Default))
            {
                bulk.DestinationTableName = "TBL_A";
                bulk.BatchSize = batchSize;
                if (timeoutSec > 0) bulk.BulkCopyTimeout = timeoutSec;

                bulk.ColumnMappings.Add("ID", "ID");
                bulk.ColumnMappings.Add("TS", "TS");
                bulk.ColumnMappings.Add("VAL", "VAL");

                using (var dt = ToDataTableA(rows))
                {
                    await bulk.WriteToServerAsync(dt).ConfigureAwait(false);
                }
            }
        }
    }

    public static async Task BulkInsertBAsync(string connStr, IReadOnlyList<RowB> rows,
        int batchSize = 5000, int timeoutSec = 0, bool useInternalTxn = True)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var bulk = new OracleBulkCopy(conn, useInternalTxn ? OracleBulkCopyOptions.UseInternalTransaction : OracleBulkCopyOptions.Default))
            {
                bulk.DestinationTableName = "TBL_B";
                bulk.BatchSize = batchSize;
                if (timeoutSec > 0) bulk.BulkCopyTimeout = timeoutSec;

                bulk.ColumnMappings.Add("ID", "ID");
                bulk.ColumnMappings.Add("CODE", "CODE");
                bulk.ColumnMappings.Add("QTY", "QTY");

                using (var dt = ToDataTableB(rows))
                {
                    await bulk.WriteToServerAsync(dt).ConfigureAwait(false);
                }
            }
        }
    }

    public static async Task BulkInsertCAsync(string connStr, IReadOnlyList<RowC> rows,
        int batchSize = 5000, int timeoutSec = 0, bool useInternalTxn = True)
    {
        if (rows == null || rows.Count == 0) return;
        using (var conn = new OracleConnection(connStr))
        {
            await conn.OpenAsync().ConfigureAwait(false);
            using (var bulk = new OracleBulkCopy(conn, useInternalTxn ? OracleBulkCopyOptions.UseInternalTransaction : OracleBulkCopyOptions.Default))
            {
                bulk.DestinationTableName = "TBL_C";
                bulk.BatchSize = batchSize;
                if (timeoutSec > 0) bulk.BulkCopyTimeout = timeoutSec;

                bulk.ColumnMappings.Add("EVENT_ID", "EVENT_ID");
                bulk.ColumnMappings.Add("TS", "TS");
                bulk.ColumnMappings.Add("PAYLOAD", "PAYLOAD");

                using (var dt = ToDataTableC(rows))
                {
                    await bulk.WriteToServerAsync(dt).ConfigureAwait(false);
                }
            }
        }
    }
}

using System;
using System.Threading.Tasks;

public enum WriterMode
{
    ArrayBinding,
    BulkCopy
}

public sealed class DbIngestion : IDisposable
{
    private readonly SimpleBuffer<RowA> _a;
    private readonly SimpleBuffer<RowB> _b;
    private readonly SimpleBuffer<RowC> _c;

    public DbIngestion(string connStr,
        WriterMode mode = WriterMode.BulkCopy,
        int countThreshold = 5000,
        int timeThresholdMs = 500)
    {
        var time = TimeSpan.FromMilliseconds(timeThresholdMs);

        if (mode == WriterMode.BulkCopy)
        {
            _a = new SimpleBuffer<RowA>(rows => BulkCopyWriters.BulkInsertAAsync(connStr, rows), countThreshold, time, true);
            _b = new SimpleBuffer<RowB>(rows => BulkCopyWriters.BulkInsertBAsync(connStr, rows), countThreshold, time, true);
            _c = new SimpleBuffer<RowC>(rows => BulkCopyWriters.BulkInsertCAsync(connStr, rows), int.MaxValue, TimeSpan.FromDays(3650), false);
        }
        else
        {
            _a = new SimpleBuffer<RowA>(rows => OracleWriters.InsertAAsync(connStr, rows), countThreshold, time, true);
            _b = new SimpleBuffer<RowB>(rows => OracleWriters.InsertBAsync(connStr, rows), countThreshold, time, true);
            _c = new SimpleBuffer<RowC>(rows => OracleWriters.InsertCAsync(connStr, rows), int.MaxValue, TimeSpan.FromDays(3650), false);
        }
    }

    public void AddA(RowA row) => _a.Add(row);
    public void AddB(RowB row) => _b.Add(row);
    public void AddC(RowC row) => _c.Add(row);

    public Task FlushCNowAsync() => _c.FlushNowAsync();

    public async Task StopAsync()
    {
        await _a.StopAsync().ConfigureAwait(false);
        await _b.StopAsync().ConfigureAwait(false);
        await _c.StopAsync().ConfigureAwait(false);
    }

    public void Dispose()
    {
        _a.Dispose();
        _b.Dispose();
        _c.Dispose();
    }
}

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public sealed class SimpleBuffer<T> : IDisposable
{
    private readonly object _gate = new object();
    private readonly List<T> _buf;
    private readonly Func<IReadOnlyList<T>, Task> _flushAsync;
    private readonly int _countThreshold;
    private readonly TimeSpan _timeThreshold;
    private readonly bool _autoFlush;

    private readonly SemaphoreSlim _flushLock = new SemaphoreSlim(1, 1);
    private readonly Timer _timer;
    private volatile bool _disposed;
    private DateTime _lastFlushUtc;

    public SimpleBuffer(Func<IReadOnlyList<T>, Task> flushAsync,
                        int countThreshold,
                        TimeSpan timeThreshold,
                        bool autoFlush,
                        int initialCapacity = 8192)
    {
        _flushAsync = flushAsync ?? throw new ArgumentNullException(nameof(flushAsync));
        _countThreshold = countThreshold;
        _timeThreshold = timeThreshold;
        _autoFlush = autoFlush;
        _buf = new List<T>(initialCapacity);
        _lastFlushUtc = DateTime.UtcNow;

        var period = timeThreshold.TotalMilliseconds < 200 ? 100 : (int)(timeThreshold.TotalMilliseconds / 2);
        _timer = new Timer(OnTimer, null, dueTime: period, period: period);
    }

    public void Add(T item)
    {
        if (_disposed) throw new ObjectDisposedException(nameof(SimpleBuffer<T>));
        bool thresholdHit = false;
        lock (_gate)
        {
            _buf.Add(item);
            if (_autoFlush && _buf.Count >= _countThreshold) thresholdHit = true;
        }
        if (thresholdHit)
        {
            _ = FlushNowAsync();
        }
    }

    private void OnTimer(object state)
    {
        if (!_autoFlush || _disposed) return;
        var now = DateTime.UtcNow;
        bool timeDue = false;
        lock (_gate)
        {
            if (_buf.Count > 0 && (now - _lastFlushUtc) >= _timeThreshold)
                timeDue = true;
        }
        if (timeDue)
        {
            _ = FlushNowAsync();
        }
    }

    public async Task FlushNowAsync()
    {
        if (_disposed) return;
        List<T> toFlush = null;
        lock (_gate)
        {
            if (_buf.Count == 0) return;
            toFlush = new List<T>(_buf);
            _buf.Clear();
        }

        await _flushLock.WaitAsync().ConfigureAwait(false);
        try
        {
            await _flushAsync(toFlush).ConfigureAwait(false);
            _lastFlushUtc = DateTime.UtcNow;
        }
        finally
        {
            _flushLock.Release();
        }
    }

    public async Task StopAsync()
    {
        if (_disposed) return;
        _disposed = true;
        _timer.Change(Timeout.Infinite, Timeout.Infinite);
        await FlushNowAsync().ConfigureAwait(false);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _timer.Change(Timeout.Infinite, Timeout.Infinite);
        try
        {
            FlushNowAsync().GetAwaiter().GetResult();
        }
        catch { }
        finally
        {
            _timer.Dispose();
            _flushLock.Dispose();
        }
    }
}

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace IngestionDemo.Ingestion
{
    public interface ITableBuffer<T> : IAsyncDisposable
    {
        ValueTask AddAsync(T row, CancellationToken ct = default);
        Task FlushNowAsync(CancellationToken ct = default);
    }

    /// <summary>
    /// Channel 기반 버퍼. 자동/수동 플러시 지원.
    /// </summary>
    public sealed class TableBuffer<T> : ITableBuffer<T>
    {
        private readonly Channel<T> _ch;
        private readonly List<T> _buf = new(capacity: 8192);
        private readonly Func<IReadOnlyList<T>, Task> _flushFunc;
        private readonly int _countThreshold;
        private readonly TimeSpan _timeThreshold;
        private readonly bool _autoFlushEnabled;
        private readonly CancellationTokenSource _cts = new();
        private readonly Task _loop;
        private readonly object _gate = new();

        private DateTime _lastFlush = DateTime.UtcNow;

        public TableBuffer(
            Func<IReadOnlyList<T>, Task> flushFunc,
            int countThreshold,
            TimeSpan timeThreshold,
            bool autoFlushEnabled = true,
            int channelCapacity = 100_000)
        {
            _flushFunc = flushFunc;
            _countThreshold = countThreshold;
            _timeThreshold = timeThreshold;
            _autoFlushEnabled = autoFlushEnabled;
            _ch = Channel.CreateBounded<T>(new BoundedChannelOptions(channelCapacity)
            {
                FullMode = BoundedChannelFullMode.Wait
            });
            _loop = Task.Run(LoopAsync);
        }

        public async ValueTask AddAsync(T row, CancellationToken ct = default)
            => await _ch.Writer.WriteAsync(row, ct);

        public async Task FlushNowAsync(CancellationToken ct = default)
        {
            List<T>? toFlush = null;
            lock (_gate)
            {
                if (_buf.Count == 0) return;
                toFlush = new List<T>(_buf);
                _buf.Clear();
            }
            await _flushFunc(toFlush!).ConfigureAwait(false);
            _lastFlush = DateTime.UtcNow;
        }

        private async Task LoopAsync()
        {
            var reader = _ch.Reader;
            try
            {
                while (await reader.WaitToReadAsync(_cts.Token).ConfigureAwait(false))
                {
                    while (reader.TryRead(out var item))
                    {
                        bool shouldFlush = false;
                        lock (_gate)
                        {
                            _buf.Add(item);
                            if (_autoFlushEnabled)
                            {
                                if (_buf.Count >= _countThreshold) shouldFlush = true;
                                else if (DateTime.UtcNow - _lastFlush >= _timeThreshold && _buf.Count > 0) shouldFlush = true;
                            }
                        }
                        if (shouldFlush) await FlushNowAsync().ConfigureAwait(false);
                    }

                    if (_autoFlushEnabled && DateTime.UtcNow - _lastFlush >= _timeThreshold)
                        await FlushNowAsync().ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException) { /* normal */ }
            finally
            {
                try { await FlushNowAsync().ConfigureAwait(false); } catch { /* swallow */ }
            }
        }

        public async ValueTask DisposeAsync()
        {
            _ch.Writer.TryComplete();
            _cts.Cancel();
            try { await _loop.ConfigureAwait(false); } catch { /* swallow */ }
            _cts.Dispose();
        }
    }
}

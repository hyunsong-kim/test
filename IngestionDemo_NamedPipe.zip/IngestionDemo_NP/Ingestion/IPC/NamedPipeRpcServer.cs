using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace IngestionDemo.Ingestion.IPC
{
    public sealed class NamedPipeRpcServer
    {
        private readonly string _pipeName;
        public NamedPipeRpcServer(string pipeName) => _pipeName = pipeName;

        public async Task RunAsync(Func<string, Task<string>> handler, CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                using var server = new NamedPipeServerStream(_pipeName, PipeDirection.InOut,
                    maxNumberOfServerInstances: 5, PipeTransmissionMode.Message, PipeOptions.Asynchronous);

                await server.WaitForConnectionAsync(ct);

                using var ms = new MemoryStream();
                var buf = new byte[8192];
                do
                {
                    int n = await server.ReadAsync(buf, 0, buf.Length, ct);
                    if (n <= 0) break;
                    ms.Write(buf, 0, n);
                } while (!server.IsMessageComplete);

                var req = Encoding.UTF8.GetString(ms.ToArray());
                var res = await handler(req);

                var outBytes = Encoding.UTF8.GetBytes(res);
                await server.WriteAsync(outBytes, 0, outBytes.Length, ct);
                await server.FlushAsync(ct);
                server.WaitForPipeDrain();
            }
        }
    }
}

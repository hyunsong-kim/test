using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IngestionDemo.Ingestion.IPC
{
    public static class NamedPipeRpcClient
    {
        public static async Task<string> CallAsync(string pipeName, string request, int timeoutMs = 5000)
        {
            using var client = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
            var cts = new CancellationTokenSource(timeoutMs);
            await client.ConnectAsync(cts.Token);

            var reqBytes = Encoding.UTF8.GetBytes(request);
            await client.WriteAsync(reqBytes, 0, reqBytes.Length, cts.Token);
            await client.FlushAsync(cts.Token);

            using var ms = new MemoryStream();
            var buf = new byte[8192];
            do
            {
                int n = await client.ReadAsync(buf, 0, buf.Length, cts.Token);
                if (n <= 0) break;
                ms.Write(buf, 0, n);
            } while (!client.IsMessageComplete);

            return Encoding.UTF8.GetString(ms.ToArray());
        }
    }
}

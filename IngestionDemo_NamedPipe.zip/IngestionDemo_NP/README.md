# IngestionDemo (Named Pipe IPC 포함)

C# 실시간 적재 템플릿 (Oracle Array Binding 기반) + .NET 6용 Named Pipe IPC로 Remoting 대체.

## 구성
- `Ingestion/Models.cs` : 테이블 A,B,C 행 모델
- `Ingestion/TableBuffer.cs` : 채널 기반 버퍼 + 자동/수동 플러시
- `Ingestion/OracleWriters.cs` : Oracle Array Binding 삽입
- `Ingestion/DbIngestion.cs` : A/B 자동, C 수동 플러시 조합
- `Ingestion/PartitionedBuffer.cs` : 파티션 기반 병렬 라우팅(옵션)
- `Ingestion/IPC/NamedPipeRpcServer.cs` : Named Pipe 서버
- `Ingestion/IPC/NamedPipeRpcClient.cs` : Named Pipe 클라이언트
- `Program.cs` : 서버 기동 및 데모(클라이언트에서 flushC 호출)

## 빌드/실행
```bash
dotnet restore
dotnet run
```

> 환경변수 `ORACLE_CONNSTR`를 사용해 연결문자열을 주입할 수 있습니다.

## 요청 포맷
- JSON 문자열 (예: `{"cmd":"flushC"}`)
- 응답 예: `"OK: flushC"`

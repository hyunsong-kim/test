using System;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using IngestionDemo.Ingestion;
using IngestionDemo.Ingestion.IPC;

internal class Program
{
    static async Task Main(string[] args)
    {
        var connStr = Environment.GetEnvironmentVariable("ORACLE_CONNSTR") ?? "User Id=user;Password=pass;Data Source=HOST:1521/SERVICE;";
        var pipeName = "IngestionPipe";

        await using var ingestion = new DbIngestion(connStr);

        // 샘플 데이터 투입 (A/B auto, C manual)
        for (int i = 0; i < 5000; i++)
        {
            await ingestion.AddAAsync(new RowA(i, DateTime.UtcNow, i * 0.1m));
            await ingestion.AddBAsync(new RowB(i, "CD" + (i % 10), i % 100));
            await ingestion.AddCAsync(new RowC(Guid.NewGuid(), DateTime.UtcNow, $"payload-{i}"));
        }

        // Named Pipe 서버 기동: flushC 명령 처리
        var cts = new CancellationTokenSource();
        var server = new NamedPipeRpcServer(pipeName);
        _ = server.RunAsync(async req =>
        {
            try
            {
                using var doc = JsonDocument.Parse(req);
                var cmd = doc.RootElement.GetProperty("cmd").GetString();
                if (string.Equals(cmd, "flushC", StringComparison.OrdinalIgnoreCase))
                {
                    await ingestion.FlushCNowAsync();
                    return "OK: flushC";
                }
                return "ERR: unknown cmd";
            }
            catch (Exception ex)
            {
                return "ERR: " + ex.Message;
            }
        }, cts.Token);

        Console.WriteLine($"Named Pipe server started on '{pipeName}'. Press Enter to send a demo flushC and exit.");

        // 데모 클라이언트 호출 (원하면 외부 프로세스에서 동일 명령 보내도 됨)
        var demoReq = JsonSerializer.Serialize(new { cmd = "flushC" });
        var resp = await NamedPipeRpcClient.CallAsync(pipeName, demoReq);
        Console.WriteLine("Client response: " + resp);

        Console.WriteLine("Press Enter to exit...");
        Console.ReadLine();
        cts.Cancel();
    }
}
